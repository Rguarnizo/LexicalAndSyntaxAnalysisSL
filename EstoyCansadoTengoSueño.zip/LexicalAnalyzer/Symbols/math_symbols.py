#!/usr/bin/env python3



math_simbolos = {
    '.': 'tk_punto',
    '+': 'tk_suma',
    '-': 'tk_resta',
    '/': 'tk_division',
    '*': 'tk_multiplicacion',
}
