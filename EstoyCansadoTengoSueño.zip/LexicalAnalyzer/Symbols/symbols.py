#!/usr/bin/env python3

simbolos = {'%': 'tk_modulo',
 '(': 'tk_parentesis_izquierdo',
 ')': 'tk_parentesis_derecho',
 ',': 'tk_coma',
 ':': 'tk_dos_puntos',
 ';': 'tk_punto_y_coma',
 '[': 'tk_corchete_izquierdo',
 ']': 'tk_corchete_derecho',
 '^': 'tk_potenciacion',
 '{': 'tk_llave_izquierda',
 '}': 'tk_llave_derecha',
 "'": 'tk_comilla',
 '"': 'tk_comilla_doble',
 }
